<?php
class Dashboard_model
{
    private $db;
}
