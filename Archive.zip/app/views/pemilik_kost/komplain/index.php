<section id="komplain" class="content">
    <h1>ini adalah halaman komplain</h1>
</section>